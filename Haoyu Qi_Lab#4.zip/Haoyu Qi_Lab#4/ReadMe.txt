Version: Java 8;
SDK: 16 Oracle OpenJDK Version 16.0.1;
IDE: Intellij;



Initiate the conversion by typing your I/O path like:

java lab4 C:\...\input.txt C:\...Output.txt

integrate output information are stored in the Excel attached.


checkcorrect is the program to sort the input file then output the sorted file, you can use this to check the correctness of the program with a small size of input file.

Lab4 is the program to output the statics result of the different kinds of sorting methods without output the sorted file, you can input a very large file.

IMPORTANT: 
All of the sorting algorithm are recursive, both checkcorrect or Lab4 will run all of them and output, so be sure to check your JVM stack and memory size, if there is a stack overflow error, that IS NOT a program incorrectness, it can be solved by modify the JVM stack and memory size like the command line below:

java -Xss10m Lab4 [] []