The lab's file required 15 files, but I mixed the 15 files into 3 files, each one encoded the information of 5 sorted methods.
This is allowed by Dr. Richard Cost as the the email he reply me.