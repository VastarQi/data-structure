/**
 * this is the class to determine a list
 */
public class list {
    public int data;
    public list next;
    public list(int data) {
        this.data=data;
    }
}
