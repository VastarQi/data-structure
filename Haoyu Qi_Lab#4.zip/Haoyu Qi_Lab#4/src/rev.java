import java.io.*;

public class rev {
    public static void main(String[] args) throws IOException {
        BufferedWriter complexity;
        if (args.length != 1) {
            System.out.println("Usage: java Lab3 [input] [output-complexity statistic]");
            System.exit(1);
            //check the input file path
        }
        try {
            complexity = new BufferedWriter(new FileWriter(args[0]));

        } catch (Exception ioe) {
            System.err.println(ioe.toString());
            return;
        }
        for (int i=0;i<1000;i++){
        complexity.write(Integer.toString(i)+"\n");
        }
        complexity.close();
}}
