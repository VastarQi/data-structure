import java.security.PublicKey;

/**
 * this is calculate the exchange, compare numbers and runing times.
 */
public class getComplexity {
    public static int C1=0;
    public static int E1=0;
    public static long T1=0;
    public static int C2=0;
    public static int E2=0;
    public static long T2=0;
    public static int C3=0;
    public static int E3=0;
    public static long T3=0;
    public static int C4=0;
    public static int E4=0;
    public static long T4=0;
    public static int C5=0;
    public static int E5=0;
    public static long T5=0;
    public static String result="";
    public static long timestart=System.currentTimeMillis();
    public static long timeend=System.currentTimeMillis();

    public static String getC(int[] arr,list Node){
        //set a copy of the input array, because the array will be sorted after a method, we can use the copy to
        //reset the input for the next method
        int []temp = new int[arr.length];
        for(int i=0;i<arr.length;i++){
            temp[i]=arr[i];}

        timestart=System.nanoTime();
        Quick1.reset();
        Quick1.quicksort1(arr,0,arr.length-1);
        timeend=System.nanoTime();
        C1=Quick1.comparisons; E1=Quick1.exchange; T1=timeend-timestart;
        for(int i=0;i<arr.length;i++){
            arr[i]=temp[i];}


        timestart=System.nanoTime();
        Quick1.reset();
        Quick1.HybridQuick50(arr,0,arr.length-1);
        timeend=System.nanoTime();
        C2=Quick1.comparisons; E2=Quick1.exchange; T2=timeend-timestart;
        for(int i=0;i<arr.length;i++){
            arr[i]=temp[i];}

        timestart=System.nanoTime();
        Quick1.reset();
        Quick1.HybridQuick100(arr,0,arr.length-1);
        timeend=System.nanoTime();
        C3=Quick1.comparisons; E3=Quick1.exchange; T3=timeend-timestart;
        for(int i=0;i<arr.length;i++){
            arr[i]=temp[i];}

        timestart=System.nanoTime();
        Quick1.reset();
        Quick1.MidQuickSort(arr,0,arr.length-1);
        timeend=System.nanoTime();
        C4=Quick1.comparisons; E4=Quick1.exchange; T4=timeend-timestart;
        for(int i=0;i<arr.length;i++){
            arr[i]=temp[i];}



        timestart=System.nanoTime();
        Merge.reset();
        Merge.merge(LinkedList.toList(arr));
        timeend=System.nanoTime();
        C5=Merge.comparisons+LinkedList.comparesion;E5=Merge.exchange;T5 =timeend-timestart;
        arr=temp;


        result="Quick sort exchange number is:  "+E1+"\n"+"Quick sort compare number is:   "+C1+"\n"+"Running Time: "+T1+"ns \n"+"---\n"
                +"50 partition Quick sort exchange number is:  "+E2+"\n"+"50 partition Quick sort compare number is:   "+C2+"\n"+"Running Time: "+T2+"ns \n"+"---\n"
                +"100 partition Quick sort exchange number is:  "+E3+"\n"+"100 partition Quick sort compare number is:   "+C3+"\n"+"Running Time: "+T3+"ns \n"+"---\n"
                +"med-of-3 Quick sort exchange number is:  "+E4+"\n"+"med-of-3 Quick sort compare number is:   "+C4+"\n"+"Running Time: "+T4+"ns \n"+"---\n"
                +"naturel merge sort exchange number is:  "+E5+"\n"+"naturel merge sort compare number is:   "+C5+"\n"+"Running Time: "+T5+"ns \n"+"---\n";

//        result="ex  "+E1+"\t"+E2+"\t"+E3+"\t"+E4+"\t"+E5+"\n"+
//                "co  "+C1+"\t"+C1+"\t"+C3+"\t"+C4+"\t"+C5+"\n"+
//                "TI  "+T1+"\t"+T2+"\t"+T3+"\t"+T4+"\t"+T5;
//        System.out.println(result);
        return result;
    }
}
