/**
 * this is the class of merge algorithm
 */
public class Merge {
    public static int comparisons=0;
    public static int exchange=0;
    //    public static long timestart=System.currentTimeMillis();
//    public static long timeend=System.currentTimeMillis();
    public static long time=0;
    public static long timestart=System.currentTimeMillis();
    public static long timeend=System.currentTimeMillis();

    /**
     * this is the merge sort algorithm using recursion
     *
     * @param Node
     * @return
     */
    public static list merge(list Node) {
        comparisons=0;
        exchange=0;
        time=0;
        timestart=System.currentTimeMillis();

        if (Node == null || Node.next == null) {
            return Node;
        }
        list BreakNode = LinkedList.getNatureBreak(Node);
        list tempnode = BreakNode.next;
        BreakNode.next = null;

        list left =Node;
        list right = merge(tempnode);

        return backRecursion(left,right);

    }

    /**
     * use recursion to merge back and gain result
     * @param list1
     * @param list2
     * @return
     */
    public static list backRecursion(list list1, list list2) {

        // Base cases
        if (list1 == null) {
            return list2;
        } else if (list2 == null)
            return list1;

        list result;
        if (list1.data <= list2.data) {
            result = list1;
            result.next = backRecursion(list1.next, list2);
            comparisons++;
            exchange++;
        } else {
            result = list2;
            result.next = backRecursion(list1, list2.next);
            comparisons++;
            exchange++;
        }
        timeend=System.currentTimeMillis();
        time=timeend-timestart;

        return result;


    }
    public static void reset(){
        comparisons=0;
        exchange=0;
    }

//    public static void main(String[] args) {
//        LinkedList test=new LinkedList();
//        test.add(1);
//        test.add(4);
//        test.add(3);
//        test.insert(2,1);
//        test.add(6);
////        test.add(1);
////        System.out.println(test.displayList(test.Head));
//        merge(test.Head);
////        System.out.println(test.displayList(test.Head));
//    }
}
