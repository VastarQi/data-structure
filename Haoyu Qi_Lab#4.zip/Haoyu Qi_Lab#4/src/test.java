public class test {
    public static void main(String[] args) {
        String s="a \n"+"b \n";
        System.out.println(s);
        int [] arr1={19,43,2,41,27,39,20,1,4,28,34,15,38,11,29,48,7,3,18,30,6,46,45,36,33,17,26,32,40,37,42,24,22,4,14,49,23,16,10,12,13,25,9,5,44,50,21,31,47};
//        Quick1.MidQuickSort(arr1,0,arr1.length-1);
        //quicksort(arr1,0,arr1.length-1);
        list Node=new list(0);
        int[]arr=new int[10];
        arr[1]=1;
        Node=LinkedList.toList(arr1);
        System.out.println(LinkedList.displayList(Node));
        Node= Merge.merge(Node);
        System.out.println(LinkedList.displayList(Merge.merge(LinkedList.toList(arr1))));
//        Quick1.HybridQuick50(arr1,0,arr1.length-1);
//        for (int k=0;k<arr1.length;k++)
//        System.out.println(arr1[k]);
//        System.out.println();
//        System.out.println(LinkedList.displayList(Merge.merge(LinkedList.toList(arr1))));
//        System.out.println(arr[1]);
    }
}
