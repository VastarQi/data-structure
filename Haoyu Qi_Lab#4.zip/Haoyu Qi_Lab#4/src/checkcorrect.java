import java.io.*;

/**
 * This is the program to sort the input file then output the sorted file,
 * Use this to check the correctness of the program with a small size of input file
 */
public class checkcorrect {
    public static void main(String[] args) throws IOException {
        BufferedReader input;
        BufferedWriter complexity;
        BufferedWriter quickSorted;
        BufferedWriter hQuick50sorted;
        BufferedWriter hQuick100sorted;
        BufferedWriter mQuickSorted;
        BufferedWriter mergeSorted;
        String AlphabetFreq = "";
        String inputCleartext="";
        char alphabet;

        if (args.length != 7) {
            System.out.println("Usage: java Lab4 [input] [output-complexity statistic] [Quick sorted][50HybridQuick sorted][100HybridQuick sorted][merge sorted]");
            System.exit(1);
            //check the input file path
        }
        try {
            input=new BufferedReader(new FileReader(args[0]));
            complexity = new BufferedWriter(new FileWriter(args[1]));
            quickSorted = new BufferedWriter(new FileWriter(args[2]));
            hQuick50sorted = new BufferedWriter(new FileWriter(args[3]));
            hQuick100sorted = new BufferedWriter(new FileWriter(args[4]));
            mQuickSorted = new BufferedWriter(new FileWriter(args[5]));
            mergeSorted = new BufferedWriter(new FileWriter(args[6]));

        } catch (Exception ioe) {
            System.err.println(ioe.toString());
            return;
        }
        int []temparray = new int[10000]; int i=0;int j=0;
        String inputNumber="";String strarr="";
        list listinput=new list(0);
        while ((inputNumber= input.readLine())!=null) {
            j = Integer.parseInt(inputNumber.trim());
            temparray[i]=j;
            i++;
        }
        int []arrinput=new int[i];
        for (int k=0;k<arrinput.length;k++){
            arrinput[k]=temparray[k];
        }
        listinput=LinkedList.toList(arrinput);

        getComplexity C= new getComplexity();
        complexity.write(C.getC(arrinput,LinkedList.toList(arrinput)));
        complexity.close();
        String s="";

//                for (int k=0;k<arrinput.length;k++){
//        System.out.println(arrinput[k]);
//        System.out.println();
        Quick1.quicksort1(arrinput,0,arrinput.length-1);

        for (int x=0;x<arrinput.length;x++){
            s=Integer.toString(arrinput[x]);
            quickSorted.write(s+"\n");
        }
        quickSorted.close();
        for (int k=0;k<arrinput.length;k++){
            arrinput[k]=temparray[k];
        }


        Quick1.HybridQuick50(arrinput,0,arrinput.length-1);

        for (int x=0;x<arrinput.length;x++){
            s=Integer.toString(arrinput[x]);
            hQuick50sorted.write(s+"\n");
        }
        hQuick50sorted.close();
        for (int k=0;k<arrinput.length;k++){
            arrinput[k]=temparray[k];
        }


        Quick1.HybridQuick100(arrinput,0,arrinput.length-1);
        for (int x=0;x<arrinput.length;x++){
            s=Integer.toString(arrinput[x]);
            hQuick100sorted.write(s+"\n");
        }
        hQuick100sorted.close();
        for (int k=0;k<arrinput.length;k++){
            arrinput[k]=temparray[k];
        }


        Quick1.MidQuickSort(arrinput,0,arrinput.length-1);
        for (int x=0;x<arrinput.length;x++){
            s=Integer.toString(arrinput[x]);
            mQuickSorted.write(s+"\n");
        }
        mQuickSorted.close();
        for (int k=0;k<arrinput.length;k++){
            arrinput[k]=temparray[k];
        }



        mergeSorted.write(LinkedList.displayList(Merge.merge(LinkedList.toList(arrinput))));
        mergeSorted.close();
//        LinkedList.displayList(listinput);
//        mergeSorted.write(LinkedList.displayList(Merge.merge(listinput)));
//        System.out.println(LinkedList.displayList(Merge.merge(listinput)));

//        int show=0;
//        list temp=new list(listinput.data);
//        if (temp==null){
//            mergeSorted.close();
//        }
//        temp=listinput;
//        System.out.println();
//        System.out.println(LinkedList.displayList(temp));
//        while (temp!=null){
//            show=temp.data;
//            s=Integer.toString(show);
//            mergeSorted.write(s+"\n");
//            temp=temp.next;
//        }
//        mergeSorted.close();






    }}
