import java.io.*;
import java.util.Arrays;

/**
 * this is the program to output the statics result of the different kinds of sorting methods without output the
 * sorted file, you can input a very large file.
 */
public class Lab4 {
    public static void main(String[] args) throws IOException {
        BufferedReader input;
        BufferedWriter complexity;
        if (args.length != 2) {
            System.out.println("Usage: java Lab4 [input] [output-complexity statistic]");
            System.exit(1);
            //check the input file path
        }
        try {
            input = new BufferedReader(new FileReader(args[0]));
            complexity = new BufferedWriter(new FileWriter(args[1]));

        } catch (Exception ioe) {
            System.err.println(ioe.toString());
            return;
        }
        int []temparray = new int[10000]; int i=0;int j=0;
        String inputNumber="";String strarr="";
        list listinput=new list(0);
        while ((inputNumber= input.readLine())!=null) {
            j = Integer.parseInt(inputNumber.trim());
            temparray[i]=j;
            i++;
        }
        int []arrinput=new int[i];
        for (int k=0;k<arrinput.length;k++){
            arrinput[k]=temparray[k];
        }


        getComplexity C= new getComplexity();
        complexity.write(C.getC(arrinput,LinkedList.toList(arrinput)));
        complexity.close();
    }
}